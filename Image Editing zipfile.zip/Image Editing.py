 #Importing the Libraries
import numpy
import cv2
from matplotlib import pyplot as plt

#Image Heading
ORGINAL_IMAGE = "Orginal Image"
BLUR_IMAGE = "Blur Image"
CROP_IMAGE = "Crop Image"
GRAYSCALE_IMAGE = "Gray scale Image"
OPEN_EROSION_IMAGE = "Open Erosion Image"
CANNY_EDGE_IMAGE = "Canny Edge Detected Image"

#Blurring the given image
#
#@img    Input Image
#@return Blurred Image
def blurImage(img):
    rows,cols = img.shape[:2]
    kernel_25 = numpy.ones((25,25),numpy.float32) / 625.0
    return cv2.filter2D(img , -1 , kernel_25)

#Cropping the given image
#
#@img    Input Image
#@return Cropped Image
def cropImage(img):
    return img[50:180, 100:300]

#To convert the given colored image to Grayscale image 
#
#@img    Input Image
#@return Grayscale Image
def grayScaleImage(img):
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

#Opening Erosion the given image
#
#@img    Input Image
#@return Open Erosion Image
def openErosionImage(img):
    kernal = numpy.ones((5,5), numpy.uint8)
    return cv2.morphologyEx(img, cv2.MORPH_OPEN, kernal)

#To Detect the edge of the object in the given image
#
#@img    Input Image
#@return Edge Detected Image
def cannyEdgeDetection(img):
    return cv2.Canny(img, 100, 200)

#MAIN PROGRAM
img = cv2.imread('D:\\grayscale\\Screenshot-2741-300x213.png')
print("Please Choose Your Below Option")
print("1. " + BLUR_IMAGE)
print("2. " + CROP_IMAGE)
print("3. " + GRAYSCALE_IMAGE)
print("4. " + OPEN_EROSION_IMAGE)
print("5. " + CANNY_EDGE_IMAGE)

#Get the input from user to perform the operation
inputOption = int(input())

#To display the Orginal Image
cv2.imshow("INPUT IMAGE --> " + ORGINAL_IMAGE, img)

#To perform the operation performed by the user
print("See the Output")
if (inputOption == 1): cv2.imshow("IMAGE-->"+BLUR_IMAGE, blurImage(img))
elif (inputOption == 2): cv2.imshow("IMAGE-->"+CROP_IMAGE, cropImage(img))
elif (inputOption == 3): cv2.imshow("IMAGE-->"+GRAYSCALE_IMAGE, grayScaleImage(img))
elif (inputOption == 4): cv2.imshow("IMAGE-->"+OPEN_EROSION_IMAGE, openErosionImage(img))
elif (inputOption == 5): cv2.imshow("IMAGE-->"+CANNY_EDGE_IMAGE, cannyEdgeDetection(img))
else: print("Invalid Operation")
